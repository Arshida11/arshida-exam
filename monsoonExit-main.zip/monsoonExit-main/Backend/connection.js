const mongoose = require("mongoose");
//Write missing code here
mongoose
  .connect(
    "mongodb+srv://tmindrajith11:JT7jAQL4cmGGjW4H@cluster0.p6cnsko.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0",
    {}
  )
  .then(() => {
    console.log("Connected to DB");
  })
  .catch((error) => {
    console.log(error);
  });